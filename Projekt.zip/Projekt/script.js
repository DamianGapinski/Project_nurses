window.sr = ScrollReveal();
sr.reveal('.img_ga, .img_happy, .img_price, p, h2, i, ul, .img, h3',{delay:300})